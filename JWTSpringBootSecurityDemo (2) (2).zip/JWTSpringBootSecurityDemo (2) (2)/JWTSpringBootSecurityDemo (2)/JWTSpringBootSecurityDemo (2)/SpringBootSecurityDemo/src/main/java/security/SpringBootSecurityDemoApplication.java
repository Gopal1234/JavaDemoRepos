package security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication

public class SpringBootSecurityDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSecurityDemoApplication.class, args);
	/*
	 * 
	 * user name-Ankit
pass-Ankit@123
type user

admin name-Gopal
pass-Gopal@123
type-admin
	 */
	
	}

}
