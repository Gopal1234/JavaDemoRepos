package com.security.Sep2KolSpringSecutiryJwt.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.security.Sep2KolSpringSecutiryJwt.service.CustomerService;
import com.security.Sep2KolSpringSecutiryJwt.utility.JwtFilter;



@Configuration
@EnableWebSecurity
//@EnableWebSecutory annotation enables spring security's web securiry support 
/*
 * so that we can authenticate and authorized our end point urls in more customizable way
 * 
 * 
 */
public class SecutiryConfig {
	
	@Autowired
	private CustomerService userDeatailsService;
	 @Autowired

	    private JwtFilter jwtFilter;
	
	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http)throws Exception
	{
		/* CSRF stands for Cross site Request Forgery 
		 * It is a type web security attack
		 * and spring security provides built in protection against it
		 * 
		 * It is a malicious website tricks a logged in user's browsers into making
		 * unwanted request to our web application
		 * HTTP
		 * 
		 * 
		 * 
		 * if you want to implement stateless RESTfull API and use JWT token in that case we 
		 * generally disable our csrf 
		 * 
		 * when we use statefull rest api then we must have to enable csrf
		 * 
		 */
		http
        .csrf(csrf -> csrf.disable())
        .cors(Customizer.withDefaults())
        .authorizeHttpRequests(auth -> auth
            // Swagger + OpenAPI
            .requestMatchers(
                "/swagger-ui.html",
                "/swagger-ui/**",
                "/v3/api-docs/**",
                "/v3/api-docs.yaml",
                "/swagger-resources/**",
                "/webjars/**"
            ).permitAll()
            // Auth endpoints
            .requestMatchers("/auth/register", "/auth/login")
            .permitAll()
            // Protected endpoints
            .requestMatchers("/admin").hasRole("ADMIN")
            .requestMatchers("/user").hasAnyRole("USER", "ADMIN")
            .anyRequest().authenticated()
        )
        .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS));

    http.addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);

    return http.build();
		
	}
	
	@Bean
	public AuthenticationManager authmanager
	(HttpSecurity http, PasswordEncoder encoder)throws Exception
	{
		return http.getSharedObject(AuthenticationManagerBuilder.class).
				userDetailsService(userDeatailsService).
				passwordEncoder(encoder).and().build();
	}
	
	@Bean
	public PasswordEncoder passwordEncoder()
	{
		return new BCryptPasswordEncoder();
	}
	

}
