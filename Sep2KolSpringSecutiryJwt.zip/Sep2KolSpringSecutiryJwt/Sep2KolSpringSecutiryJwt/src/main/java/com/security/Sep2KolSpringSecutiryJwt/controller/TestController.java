package com.security.Sep2KolSpringSecutiryJwt.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {
	
	
	@GetMapping("/user")
	public List<String> getUser()
	{
		return List.of("VIEW_PRODUCT","MAKE_ORDER");
	}
	@GetMapping("/admin")
	public List<String> getAdmin()
	{
		return List.of("CREATE_PRODUCT","CHECK_ORDER");
	}

}
