package com.security.Sep2KolSpringSecutiryJwt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.security.Sep2KolSpringSecutiryJwt.dto.LoginDTO;
import com.security.Sep2KolSpringSecutiryJwt.dto.UserDTO;
import com.security.Sep2KolSpringSecutiryJwt.entity.User;
import com.security.Sep2KolSpringSecutiryJwt.service.UserService;
import com.security.Sep2KolSpringSecutiryJwt.utility.JwtUtil;



@RestController
@RequestMapping("/auth")
public class UserController {
	@Autowired
	private UserService service;
	
	 @Autowired

	    private AuthenticationManager authManager;
	 
	    @Autowired

	    private JwtUtil jwtUtil;
	
	@PostMapping("/register")
	private ResponseEntity<String> 
	signUpUser(@RequestBody UserDTO dto)
	{
		System.out.println(dto.getUserName() + " "+dto.getUserPassword());
	User u=	service.registerUser(dto);
	if(u!=null)
	{
		return ResponseEntity.ok("Successfully registered");
	}
		return ResponseEntity.ok("not able to register");
	}
	
	@PostMapping("/login")

    public ResponseEntity<String> 
	login(@RequestBody LoginDTO loginDto) {

	  System.out.println(loginDto.getPassword()+" "+loginDto.getUserName());
        Authentication auth = authManager.authenticate(

            new UsernamePasswordAuthenticationToken(loginDto.getUserName(), 
            		loginDto.getPassword()));
 
        UserDetails userDetails = (UserDetails) auth.getPrincipal();
        String token=null;
        if(userDetails!=null)
        {

         token = jwtUtil.generateToken(userDetails);
        }

        return ResponseEntity.ok(token);

    }
	
	
	

}
