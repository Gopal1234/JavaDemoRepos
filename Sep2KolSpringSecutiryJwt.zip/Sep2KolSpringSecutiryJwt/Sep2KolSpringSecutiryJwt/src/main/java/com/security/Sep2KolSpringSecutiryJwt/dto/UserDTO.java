package com.security.Sep2KolSpringSecutiryJwt.dto;

import java.util.List;

public class UserDTO {
	
	private String userName;
	private String userPassword;
	private List<String> roleNames;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public List<String> getRoleNames() {
		return roleNames;
	}
	public void setRoleNames(List<String> roleNames) {
		this.roleNames = roleNames;
	}
	

}
