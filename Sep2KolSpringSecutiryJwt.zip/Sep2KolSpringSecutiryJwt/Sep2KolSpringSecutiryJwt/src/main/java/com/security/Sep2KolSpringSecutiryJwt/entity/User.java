package com.security.Sep2KolSpringSecutiryJwt.entity;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
@Entity
@Table(name="MyUser")
public class User {
	@Id
	
	private String userName;
	private String userPassword;
	private boolean isActivated=true;
	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name="USER_ROLE", 
	joinColumns =@JoinColumn(name="user_id"),
	inverseJoinColumns = @JoinColumn(name="role_id"))
	private Set<Role> roles=new HashSet();
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public boolean isActivated() {
		return isActivated;
	}
	public void setActivated(boolean isActivated) {
		this.isActivated = isActivated;
	}
	public Set<Role> getRoles() {
		return roles;
	}
	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}
	@Override
	public String toString() {
		return "User [userName=" + userName + ", userPassword=" + userPassword + ", isActivated=" + isActivated
				+ ", roles=" + roles + "]";
	}
	public User(String userName, String userPassword, boolean isActivated, Set<Role> roles) {
		super();
		this.userName = userName;
		this.userPassword = userPassword;
		this.isActivated = isActivated;
		this.roles = roles;
	}
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

}
