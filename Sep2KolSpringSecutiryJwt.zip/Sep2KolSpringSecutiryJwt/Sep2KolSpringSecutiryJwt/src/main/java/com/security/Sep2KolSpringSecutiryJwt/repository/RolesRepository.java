package com.security.Sep2KolSpringSecutiryJwt.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.security.Sep2KolSpringSecutiryJwt.entity.Role;

public interface RolesRepository extends JpaRepository<Role, String> {

}
