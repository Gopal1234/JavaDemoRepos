package com.security.Sep2KolSpringSecutiryJwt.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.security.Sep2KolSpringSecutiryJwt.entity.User;
import com.security.Sep2KolSpringSecutiryJwt.repository.UserRepository;

@Service
public class CustomerService implements UserDetailsService {
	
	@Autowired
	private UserRepository userRepos;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user=userRepos.findByUserName(username)
				.orElseThrow(()->new UsernameNotFoundException("User name not found"));
		System.out.println(user);
		List<SimpleGrantedAuthority> authorities=
				user.getRoles().stream().
				map(role->new SimpleGrantedAuthority("ROLE_"+role.getRoleName()))
				.collect(Collectors.toList());
		
		UserDetails d=new org.springframework.security.core.userdetails.User
				(user.getUserName(),
				 user.getUserPassword(),
				 user.isActivated(), true,true, true,authorities);
			     			
						
return d;
	}
	
	
	
	
	

}
