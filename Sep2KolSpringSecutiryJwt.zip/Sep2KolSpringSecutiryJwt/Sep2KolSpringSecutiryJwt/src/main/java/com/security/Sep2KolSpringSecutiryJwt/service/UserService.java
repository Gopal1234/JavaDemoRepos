package com.security.Sep2KolSpringSecutiryJwt.service;

import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.RuntimeJsonMappingException;
import com.security.Sep2KolSpringSecutiryJwt.dto.UserDTO;
import com.security.Sep2KolSpringSecutiryJwt.entity.Role;
import com.security.Sep2KolSpringSecutiryJwt.entity.User;
import com.security.Sep2KolSpringSecutiryJwt.repository.RolesRepository;
import com.security.Sep2KolSpringSecutiryJwt.repository.UserRepository;

@Service
public class UserService {
 
	private UserRepository userRepos;
     
	private RolesRepository rolesRepos;
	
	@Autowired
	private PasswordEncoder encoder;
	public UserService(UserRepository userRepos, RolesRepository rolesRepos) {
		
		this.userRepos = userRepos;
		this.rolesRepos = rolesRepos;
	}

	
	public User registerUser(UserDTO dto)
	{
		User user=new User();
		user.setUserName(dto.getUserName());
		user.setUserPassword(encoder.encode(dto.getUserPassword()));
		//user.setUserPassword(dto.getUserPassword());
		user.setActivated(true);
		//List<String>.stream()--
		Set<Role> roles= dto.getRoleNames().stream().
		 map(roleName->rolesRepos.findById(roleName)
				 .orElseThrow(()->new RuntimeException("role name not found")))
		 .collect(Collectors.toSet());
		
		user.setRoles(roles);
		return userRepos.save(user);
		
		
		
		
		
	}
	
	
	

}
