package com.security.Sep2KolSpringSecutiryJwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sep2KolSpringSecutiryJwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
